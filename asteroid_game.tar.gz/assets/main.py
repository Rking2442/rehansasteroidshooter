
import asyncio
import math
import random


import pygame

pygame.init()

WIDTH = 800
HEIGHT = 600
MISSILE_SPEED = 7
ROTATION_SPEED = 3
THRUST = 0.15
DRAG = 0.99
MAX_SPEED = 7

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Rehans missiles")
clock = pygame.time.Clock()
font = pygame.font.SysFont("dejavusansmono", 22, bold=True)

class Enemy:
    def __init__(self, position):
        self.position = pygame.Vector2(position)
        self.velocity = pygame.Vector2(0, 0)
        self.acceleration = pygame.Vector2(0, 0)
        self.radius = 18
        self.angle = 0
        self.is_thrusting = False
        self.phase = "patrol"
        self.patrol_speed = 2
        self.patrol_left = max(self.radius, self.position.x - 120)
        self.patrol_right = min(WIDTH - self.radius, self.position.x + 120)
        self.patrol_direction = 1
        self.view_range = 280
        self.view_half_angle = 45

    @property
    def forward(self):
        radians = math.radians(self.angle)
        return pygame.Vector2(math.cos(radians), -math.sin(radians))

    def can_see(self, target_position):
        direction = pygame.Vector2(target_position) - self.position
        if direction.length_squared() == 0 or direction.length() > self.view_range:
            return False

        dot = self.forward.dot(direction.normalize())
        return dot >= math.cos(math.radians(self.view_half_angle))

    def update(self, target_position):
        if self.can_see(target_position):
            self.phase = "attack"
        else:
            self.phase = "patrol"

        if self.phase == "attack":
            direction = pygame.Vector2(target_position) - self.position
            self.angle = -math.degrees(math.atan2(direction.y, direction.x))
            self.is_thrusting = True
            self.acceleration = self.forward * THRUST
            self.velocity += self.acceleration
            self.velocity *= DRAG
            if self.velocity.length() > MAX_SPEED:
                self.velocity.scale_to_length(MAX_SPEED)
            self.position += self.velocity
        else:
            self.is_thrusting = False
            self.velocity = pygame.Vector2(self.patrol_direction * self.patrol_speed, 0)
            self.position.x += self.velocity.x
            if self.position.x >= self.patrol_right:
                self.position.x = self.patrol_right
                self.patrol_direction = -1
            elif self.position.x <= self.patrol_left:
                self.position.x = self.patrol_left
                self.patrol_direction = 1
            self.angle = 0 if self.patrol_direction > 0 else 180

        self.position.x %= WIDTH
        self.position.y %= HEIGHT

    def draw(self, surface):
        forward = self.forward
        left = forward.rotate(140)
        right = forward.rotate(-140)

        points = [
            self.position + forward * 12,
            self.position + left * 6,
            self.position + right * 6,
        ]
        if self.is_thrusting:
            flame_tip = self.position - forward * random.randint(24, 34)
            pygame.draw.polygon(
                surface,
                (255, 120, 30),
                [
                    self.position - forward * 14,
                    self.position - forward * 14 + left * 6,
                    flame_tip,
                    self.position - forward * 14 + right * 6,
                ],
            )
        pygame.draw.polygon(surface, (80, 200, 255), points)
        pygame.draw.polygon(surface, (220, 245, 255), points, 2)
        pygame.draw.circle(surface, (255, 220, 80), self.position, 5)

class Ship:
    def __init__(self, position):
        self.position = pygame.Vector2(position)
        self.velocity = pygame.Vector2(0, 0)
        self.acceleration = pygame.Vector2(0, 0)
        self.radius = 18
        self.angle = 90
        self.is_thrusting = False

    def update(self, keys):
        self.acceleration = pygame.Vector2(0, 0)
        self.is_thrusting = keys[pygame.K_UP] or keys[pygame.K_w]
        if self.is_thrusting:
            self.acceleration = self.forward * THRUST
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.acceleration -= self.forward * THRUST

        self.velocity += self.acceleration
        self.velocity *= DRAG
        if self.velocity.length() > MAX_SPEED:
            self.velocity.scale_to_length(MAX_SPEED)

        self.position += self.velocity
        self.position.x %= WIDTH
        self.position.y %= HEIGHT

    @property
    def forward(self):
        radians = math.radians(self.angle)
        return pygame.Vector2(math.cos(radians), -math.sin(radians))

    def draw(self, surface):
        forward = self.forward
        left = forward.rotate(140)
        right = forward.rotate(-140)
        points = [
            self.position + forward * 22,
            self.position + left * 16,
            self.position + right * 16,
        ]
        if self.is_thrusting:
            flame_tip = self.position - forward * random.randint(24, 34)
            pygame.draw.polygon(
                surface,
                (255, 120, 30),
                [self.position - forward * 14, self.position - forward * 14 + left * 6, flame_tip,
                 self.position - forward * 14 + right * 6],
            )
        pygame.draw.polygon(surface, (80, 200, 255), points)
        pygame.draw.polygon(surface, (220, 245, 255), points, 2)
        pygame.draw.circle(surface, (255, 220, 80), self.position, 5)


class Missile:
    def __init__(self, start_position, direction):
        self.position = pygame.Vector2(start_position)
        self.radius = 5

        direction = pygame.Vector2(direction)
        if direction.length_squared() == 0:
            direction = pygame.Vector2(0, -1)
        else:
            direction = direction.normalize()
        self.velocity = direction * MISSILE_SPEED

    def update(self):
        self.position += self.velocity

    def is_offscreen(self):
        return not pygame.Rect(0, 0, WIDTH, HEIGHT).collidepoint(self.position)

    def draw(self, surface):
        forward = self.velocity.normalize()
        side = forward.rotate(90)
        base = self.position - forward * 2
        poop_brown = (135, 75, 35)
        outline = (75, 40, 20)

        # Layered lobes make the tiny missile look like a little poop.
        pygame.draw.circle(surface, outline, base, 5)
        pygame.draw.circle(surface, poop_brown, base, 4)
        pygame.draw.circle(surface, outline, self.position + forward * 1, 3)
        pygame.draw.circle(surface, poop_brown, self.position + forward * 1, 2)
        pygame.draw.circle(surface, outline, self.position + forward * 3, 2)
        pygame.draw.circle(surface, (190, 125, 70), self.position + forward * 3, 1)
        pygame.draw.circle(surface, (190, 125, 70), base - side * 1.5, 1)


class Asteroid:
    def __init__(self, position, velocity, radius):
        self.position = pygame.Vector2(position)
        self.velocity = pygame.Vector2(velocity)
        self.radius = radius
        self.mass = radius**2

    def update(self):
        self.position += self.velocity

        if self.position.x - self.radius <= 0:
            self.position.x = self.radius
            self.velocity.x *= -1
        elif self.position.x + self.radius >= WIDTH:
            self.position.x = WIDTH - self.radius
            self.velocity.x *= -1

        if self.position.y - self.radius <= 0:
            self.position.y = self.radius
            self.velocity.y *= -1
        elif self.position.y + self.radius >= HEIGHT:
            self.position.y = HEIGHT - self.radius
            self.velocity.y *= -1

    def draw(self, surface):
        pygame.draw.circle(
            surface,
            (180, 20, 180),
            (int(self.position.x), int(self.position.y)),
            self.radius,
        )
        pygame.draw.circle(
            surface,
            (100, 100, 100),
            (int(self.position.x), int(self.position.y)),
            self.radius,
            2,
        )


def create_asteroid():
    radius = random.randint(15, 85)
    position = pygame.Vector2(
        random.randint(radius, WIDTH - radius),
        random.randint(radius, HEIGHT - radius),
    )
    angle = random.uniform(0, 2 * math.pi)
    speed = random.uniform(1.5, 5)
    velocity = pygame.Vector2(math.cos(angle), math.sin(angle)) * speed
    return Asteroid(position, velocity, radius)


def handle_collision(a, b):
    difference = b.position - a.position
    distance = difference.length()

    if distance == 0:
        difference = pygame.Vector2(1, 0)
        distance = 1

    if distance <= a.radius + b.radius:
        normal = difference.normalize()
        relative_velocity = b.velocity - a.velocity
        velocity_along_normal = relative_velocity.dot(normal)

        if velocity_along_normal > 0:
            return

        impulse = -2 * velocity_along_normal
        impulse /= (1 / a.mass) + (1 / b.mass)
        impulse_vector = normal * impulse

        a.velocity -= impulse_vector / a.mass
        b.velocity += impulse_vector / b.mass

        overlap = a.radius + b.radius - distance
        a.position -= normal * (overlap * b.mass / (a.mass + b.mass))
        b.position += normal * (overlap * a.mass / (a.mass + b.mass))


async def main():
    ship = Ship((WIDTH / 2, HEIGHT / 2))
    enemy = Enemy((WIDTH - 150, HEIGHT-150))
    asteroids = [create_asteroid() for _ in range(6)]
    missiles = []
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                missile_start = ship.position + ship.forward * 22
                missiles.append(Missile(missile_start, ship.forward))

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            ship.angle += ROTATION_SPEED
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            ship.angle -= ROTATION_SPEED
        ship.update(keys)
        enemy.update(ship.position)

        for asteroid in asteroids:
            asteroid.update()

        for i in range(len(asteroids)):
            for j in range(i + 1, len(asteroids)):
                handle_collision(asteroids[i], asteroids[j])

        for missile in missiles:
            missile.update()

        remaining_missiles = []
        destroyed_asteroids = set()
        for missile in missiles:
            if missile.is_offscreen():
                continue

            hit_asteroid = None
            for asteroid in asteroids:
                if missile.position.distance_to(asteroid.position) <= (
                    missile.radius + asteroid.radius
                ):
                    hit_asteroid = asteroid
                    break

            if hit_asteroid is None:
                remaining_missiles.append(missile)
            else:
                destroyed_asteroids.add(hit_asteroid)

        missiles = remaining_missiles
        asteroids = [asteroid for asteroid in asteroids if asteroid not in destroyed_asteroids]

        screen.fill((25, 105, 45))
        ship.draw(screen)
        enemy.draw(screen)
        for asteroid in asteroids:
            asteroid.draw(screen)
        for missile in missiles:
            missile.draw(screen)

        forward = ship.forward
        angle_text = font.render(f"Angle: {ship.angle % 360:.0f}°", True, (220, 220, 220))
        vector_text = font.render(
            f"Forward: ({forward.x:.2f}, {forward.y:.2f})  |  Arrows/A,D: turn  W/Up: thrust  S/Down: reverse  Space: fire",
            True,
            (220, 220, 220),
        )
        velocity_text = font.render(
            f"Velocity: ({ship.velocity.x:.2f}, {ship.velocity.y:.2f})",
            True,
            (220, 220, 220),
        )
        speed_text = font.render(f"Speed: {ship.velocity.length():.2f}", True, (220, 220, 220))
        phase_text = font.render(f"Enemy phase: {enemy.phase.upper()}", True, (220, 220, 220))
        screen.blit(angle_text, (12, 12))
        screen.blit(vector_text, (12, 36))
        screen.blit(velocity_text, (12, 60))
        screen.blit(speed_text, (12, 84))
        screen.blit(phase_text, (12, 108))
        pygame.draw.line(
            screen,
            (255, 80, 80),
            ship.position,
            ship.position + forward * 60,
            2,
        )
        pygame.draw.line(
            screen,
            (255, 220, 70),
            ship.position,
            ship.position + ship.velocity * 10,
            3,
        )
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
